$(document).ready(function () {
    $(".toggle_leftmenu").click(function() {
            $(".oe_leftbar").animate({
            width: 'toggle'
        }, 0);
    });
});
